# Shower water and scene verification

**Goal:** Complete the existing bare shower animation with fixture-anchored translucent falling water and automated graphics checks.

**Spec:** The shower direction in `2026-10-09-render-correctness.md` and the shared scene contract in `../../specs/2026-10-12-character-creator-runtime.md`.

The character-creator release supersedes the earlier sprite-only implementation assumptions. It already provides the bare body, shower clip, exact fixture routing, physical fixture depth, shared supersampled color/depth/identity, and displayed character anchors. Preserve those interfaces and all published artwork. The remaining effect must use the exported nozzle transform, remain inside the tray, and use the simulation-driven character phase. No steam, body replacement, dependency change or production promotion is part of this batch.

## Implementation

1. Test deterministic downward segments, nozzle attachment, floor bounds, all four fixture orientations and invalid registration before implementing `web/src/render/character/shower-water.ts`.
2. Add a small effect renderer and shader. Blend linear premultiplied water after opaque sprites and characters. Sort constant-depth water groups from far to near. Between groups, draw only wall and grime fragments in the intervening physical-depth interval. Keep the existing blend and in-band wall order. Test against existing opaque depth without writing depth, physical surface or categorical identity. Reuse graphics allocations; release them on reset and device loss.
3. In `CharacterWorld`, prepare emitters only for active shower actors using their exported fixture-owned nozzle matrices. Pass their constant-depth groups to `SpriteRenderer.draw`. Keep existing callers compatible. Use the uploaded Float32 group depths and separate aligned band records; never overwrite a single uniform record between encoded draws.
4. Add real graphics readback cases for transparent color, foreground/background occlusion and unchanged identity/depth. Exercise the effect through actual shower use, Pause/reduced motion, cancellation and completion. Inspect native-size and enlarged captures in four facings with representative appearances.
5. Reconcile the earlier render plan against the current renderer rather than repeating completed work. Extend shared scene regression coverage wherever this effect exposes an unguarded ownership or visibility boundary.
6. Run focused tests, the complete web suite, typecheck/build, source-preservation checks and independent adversarial visual/code review. Record actual results and remaining limits. Commit and push only the reviewed feature branch; production remains unchanged.

## Files and boundaries

`shower-water.ts` owns source-space trajectories and projection. `shower-water-renderer.ts` and its shader own effect resources and the graphics contract. `world.ts` owns activity lifetime. `transparency-bands.ts` owns transparent composition intervals; `sprites.ts` interleaves the scene contributions, and `main.ts` supplies the active water groups. New tests and a browser proof exercise those real interfaces. Do not modify character source bundles, simulation saves, fixture artwork, existing geometry, menu/book behavior or the original rig without first identifying a concrete fit defect and updating this plan.

## Review focus

1. Water must remain attached to the physical nozzle, not the Sim's moving head.
2. Transparent water must not become a solid wall or steal clicks from visible geometry.
3. An opaque wall or body in front must still occlude a stream.
4. Pause, reduced motion, leaving the shower and graphics recovery must not leave stray effects.
5. New appearances must keep their body and fixture configuration; water is a separate stylized effect, not a liquid simulation or structural support.
