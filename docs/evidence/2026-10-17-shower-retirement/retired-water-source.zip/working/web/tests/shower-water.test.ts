import {expect,it} from 'vitest';
import {showerWaterSegments,projectShowerWater,activeShowerWater,type ShowerWaterEmitter} from '../src/render/character/shower-water.js';

const nozzle=[1,0,0,0,0,-.8944285,.447211,0,0,-.447211,-.8944285,0,0,-.0755,1.709,1];
const emitter:ShowerWaterEmitter={nozzle,phase:0,angle:0,x:320,y:240,width:640,height:480,
  scale:2,depth:.5,step:.01,light:[1,1,1]};

it('binds active water to fixture-owned nozzle data and clears it for every other action',()=>{
  const prop={matrix:nozzle,visible:true,owner:'fixture'};
  expect(activeShowerWater('shower','shower',1,4,prop)).toEqual({nozzle,phase:.25});
  for(const action of ['idle','walk','bath','toilet'])expect(activeShowerWater(action,null,0,0,undefined)).toBeNull();
  expect(()=>activeShowerWater('shower','counter',0,4,prop)).toThrow();
  expect(()=>activeShowerWater('shower','shower',0,4,{...prop,owner:'body'})).toThrow();
  expect(()=>activeShowerWater('shower','shower',0,4,{...prop,visible:false})).toThrow();
});

it('emits thin separated falling segments beneath the exported nozzle and above the tray',()=>{
  const rows=showerWaterSegments(nozzle,0);
  expect(rows.length).toBeGreaterThan(8);
  for(const row of rows){
    expect(row.start[2]).toBeGreaterThan(row.end[2]);
    expect(row.start[2]).toBeLessThan(1.735);
    expect(row.end[2]).toBeGreaterThanOrEqual(.055);
    expect(Math.abs(row.start[0])).toBeLessThan(.34);
    expect(row.start[1]).toBeGreaterThan(-.34);
    expect(row.start[1]).toBeLessThan(0);
    expect(row.start.slice(0,2)).toEqual(row.end.slice(0,2));
    expect(row.start[2]-row.end[2]).toBeLessThan(.16);
  }
});

it('moves downward with phase and closes the whole loop without random state',()=>{
  const first=showerWaterSegments(nozzle,0),next=showerWaterSegments(nozzle,.01);
  expect(showerWaterSegments(nozzle,1)).toEqual(first);
  expect(showerWaterSegments(nozzle,0)).toEqual(first);
  const before=first.find(row=>row.start[2]<1.5&&row.end[2]>.3)!;
  const after=next.find(row=>row.stream===before.stream&&row.slot===before.slot)!;
  expect(after.start[2]).toBeLessThan(before.start[2]);
  expect(after.start[1]).toBeLessThan(before.start[1]);
});

it('translates with the nozzle instead of a body landmark',()=>{
  const shifted=[...nozzle];shifted[12]=.1;
  const before=showerWaterSegments(nozzle,0),after=showerWaterSegments(shifted,0);
  expect(after).toHaveLength(before.length);
  before.forEach((row,i)=>expect(after[i].start[0]-row.start[0]).toBeCloseTo(.1));
});

it('spreads from the nozzle across the source spray cone without leaving the tray',()=>{
  const rows=Array.from({length:40},(_,i)=>showerWaterSegments(nozzle,i/40)).flat();
  const xs=rows.map(row=>row.start[0]);
  expect(Math.max(...xs)-Math.min(...xs)).toBeGreaterThan(.3);
  for(const row of rows){
    expect(Math.abs(row.start[0])).toBeLessThan(.34);
    expect(Math.abs(row.start[1])).toBeLessThan(.34);
  }
});

it.each([0,Math.PI/2,Math.PI,3*Math.PI/2])('projects registered world depth at facing %s',angle=>{
  const data=projectShowerWater([{...emitter,angle}]);
  expect(data.length).toBeGreaterThan(0);
  expect(data.length%54).toBe(0);
  for(let i=0;i<data.length;i+=9){
    expect(Number.isFinite(data[i])).toBe(true);
    expect(data[i+2]).toBeGreaterThan(0);
    expect(data[i+2]).toBeLessThan(1);
    expect(data[i+3]).toBeGreaterThan(0);
    expect(data[i+3]).toBeLessThan(1);
  }
});

it('never changes output for a held phase and emits nothing without active showers',()=>{
  expect(projectShowerWater([])).toHaveLength(0);
  expect(projectShowerWater([emitter])).toEqual(projectShowerWater([emitter]));
});

it('rejects malformed or nonphysical nozzle registrations',()=>{
  for(const matrix of [[],nozzle.map((n,i)=>i===12?NaN:n),nozzle.map((n,i)=>i===14?.01:n)])
    expect(()=>showerWaterSegments(matrix,0)).toThrow();
  expect(()=>showerWaterSegments(nozzle,NaN)).toThrow();
  expect(()=>projectShowerWater([{...emitter,width:0}])).toThrow();
});
