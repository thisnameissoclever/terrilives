import {expect,it} from 'vitest';
import {transparencyBands,constantDepthGroups} from '../src/render/transparency-bands.js';

it('partitions every transparent depth exactly once, including boundaries',()=>{
  const bands=transparencyBands([.8,.5,.2]);
  for(const depth of [0,.2,.200001,.5,.8,.999,1]){
    expect(bands.filter(b=>depth>b.lower&&depth<=b.upper)).toHaveLength(1);
  }
  expect(bands.map(b=>b.layer)).toEqual([0,1,2,null]);
  expect(bands[0]).toEqual({lower:Math.fround(.8),upper:1,layer:0});
  expect(bands.at(-1)?.lower).toBe(-1);
});

it('groups uploaded Float32 depths into contiguous vertex ranges',()=>{
  const vertices=new Float32Array(18*9);
  for(let i=0;i<18;i++)vertices[i*9+2]=i<12?.7:.3;
  expect(constantDepthGroups(vertices)).toEqual([
    {depth:Math.fround(.7),first:0,count:12},{depth:Math.fround(.3),first:12,count:6}]);
  vertices[8*9+2]=.6;
  expect(()=>constantDepthGroups(vertices)).toThrow();
  expect(()=>transparencyBands([.2,.8])).toThrow();
  expect(()=>transparencyBands([.5,.5])).toThrow();
});
