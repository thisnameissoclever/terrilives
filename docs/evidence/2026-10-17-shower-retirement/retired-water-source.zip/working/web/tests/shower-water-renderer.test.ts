import {expect,it} from 'vitest';
import {showerWaterPipelineDescriptor} from '../src/render/character/shower-water-renderer.js';

it('blends water without replacing opaque depth or click ownership',()=>{
  const pipeline=showerWaterPipelineDescriptor({} as GPUShaderModule);
  expect(pipeline.depthStencil?.depthWriteEnabled).toBe(false);
  expect(pipeline.depthStencil?.depthCompare).toBe('less-equal');
  const targets=Array.from(pipeline.fragment!.targets);
  expect(targets[0]?.blend?.color).toEqual({srcFactor:'one',dstFactor:'one-minus-src-alpha',operation:'add'});
  expect(targets[1]?.writeMask).toBe(0);
  expect(targets[2]?.writeMask).toBe(0);
});
