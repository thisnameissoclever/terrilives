import {SceneTarget} from '../src/render/scene-target.js';
import {transparencyBands,drawTransparencyBands,TransparencyBandBuffer,transparencyBandShader,
  type TransparentLayers} from '../src/render/transparency-bands.js';
import {showerWaterPipelineDescriptor,ShowerWaterRenderer} from '../src/render/character/shower-water-renderer.js';
import waterShader from '../src/render/character/shower-water.wgsl?raw';
import {SpriteRenderer} from '../src/render/sprites.js';
import {writeInstance,FLOATS_PER_INSTANCE} from '../src/render/instances.js';
import {spriteIndex} from '../src/render/atlas.js';

type Color=readonly [number,number,number,number];
interface Layer {depth:number;color:Color;slope?:number}
type Mutation='tail'|'unclipped'|'overlap'|'reverse'|'depthWrite'|null;
const blend:GPUBlendComponent={srcFactor:'one',dstFactor:'one-minus-src-alpha',operation:'add'};
const source=`
struct Layer {color:vec4f, data:vec4f};
@group(0) @binding(0) var<uniform> layer:Layer;
${transparencyBandShader}
struct V {@builtin(position) clip:vec4f,@location(0) x:f32};
@vertex fn vertex(@builtin(vertex_index) i:u32)->V {
  let p=array<vec2f,3>(vec2f(-1,-1),vec2f(3,-1),vec2f(-1,3));
  var out:V;out.clip=vec4f(p[i],layer.data.x,1);out.x=p[i].x;return out;
}
struct F {@location(0) color:vec4f,@location(1) surface:f32,@location(2) identity:u32,@builtin(frag_depth) depth:f32};
@fragment fn fragment(in:V)->F {
  let depth=layer.data.x+in.x*layer.data.y;
  if(layer.data.z>0. && outsideTransparencyBand(depth)){discard;}
  var out:F;out.color=layer.color;out.surface=depth;out.identity=7u;out.depth=depth;return out;
}`;
const over=(a:Color,b:Color):Color=>[a[0]+b[0]*(1-a[3]),a[1]+b[1]*(1-a[3]),a[2]+b[2]*(1-a[3]),a[3]+b[3]*(1-a[3])];
function half(v:number):number{
  const sign=v&0x8000?-1:1,e=(v>>10)&31,m=v&1023;
  return sign*(e===0?m*2**-24:e===31?Infinity:(1+m/1024)*2**(e-15));
}

async function run(){
 const adapter=await navigator.gpu.requestAdapter();if(!adapter)throw new Error('No graphics adapter.');
 const device=await adapter.requestDevice({requiredLimits:{maxTextureDimension2D:adapter.limits.maxTextureDimension2D}});const errors:string[]=[];
 device.addEventListener('uncapturederror',e=>errors.push(e.error.message));
 const scene=new SceneTarget(device,16,8,'rgba8unorm'),bank=new TransparencyBandBuffer(device);
 const layerLayout=device.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT,buffer:{type:'uniform'}}]});
 const layout=device.createPipelineLayout({bindGroupLayouts:[layerLayout,bank.layout]});
 const module=device.createShaderModule({code:source});
 const pipeline=(transparent:boolean,depthWrite=false)=>device.createRenderPipeline({layout,
   vertex:{module,entryPoint:'vertex'},fragment:{module,entryPoint:'fragment',targets:[{format:'rgba16float',blend:{color:blend,alpha:blend}},
   {format:'r32float',writeMask:transparent?0:15},{format:'r32uint',writeMask:transparent?0:15}]},
   depthStencil:{format:'depth24plus',depthWriteEnabled:!transparent||depthWrite,depthCompare:'less-equal'}});
 const opaque=pipeline(false),transparent=pipeline(true),badDepth=pipeline(true,true);
 const resources:GPUBuffer[]=[];
 const prepare=(layer:Layer,clipped:boolean)=>{
   const buffer=device.createBuffer({size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});resources.push(buffer);
   device.queue.writeBuffer(buffer,0,new Float32Array([...layer.color,layer.depth,layer.slope??0,clipped?1:0,0]));
   return device.createBindGroup({layout:layerLayout,entries:[{binding:0,resource:{buffer}}]});
 };
 const read=async(texture:GPUTexture,bytes:number)=>{
   const row=Math.ceil(texture.width*bytes/256)*256,buffer=device.createBuffer({size:row*texture.height,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ});
   try{const encoder=device.createCommandEncoder();encoder.copyTextureToBuffer({texture},{buffer,bytesPerRow:row},[texture.width,texture.height]);
     device.queue.submit([encoder.finish()]);await buffer.mapAsync(GPUMapMode.READ);
     const raw=new Uint8Array(buffer.getMappedRange()),out=new Uint8Array(texture.width*texture.height*bytes);
     for(let y=0;y<texture.height;y++)out.set(raw.subarray(y*row,y*row+texture.width*bytes),y*texture.width*bytes);
     return out;
   }finally{buffer.unmap();buffer.destroy();}
 };
 const render=async(wall:Layer|null,streams:Layer[],mutation:Mutation=null,witness=false)=>{
   const sorted=[...streams].sort((a,b)=>b.depth-a.depth);
   const groups=sorted.map((row,index)=>({depth:Math.fround(row.depth),first:index,count:1}));
   const unique=groups.filter((row,index)=>index===0||row.depth!==groups[index-1].depth);
   const depths=unique.map(g=>g.depth),bands=transparencyBands(depths);
   if(mutation==='overlap'&&bands.length>1)bands[0].lower=0;
   bank.prepare(bands);
   const bg=prepare({depth:.9,color:[0,0,1,1]},false);
   const wallGroup=wall?prepare(wall,mutation!=='unclipped'):null;
   const streamGroups=sorted.map(row=>prepare(row,false));
   const encoder=device.createCommandEncoder(),pass=scene.begin(encoder);
   const draw=(program:GPURenderPipeline,group:GPUBindGroup)=>{pass.setPipeline(program);pass.setBindGroup(0,group);pass.draw(3);};
   bank.bind(pass,0);draw(opaque,bg);
   const variable=()=>{if(wallGroup)draw(transparent,wallGroup);};
   const layers:TransparentLayers={groups:unique,drawGroup:(_pass,index)=>{
     const depth=depths[mutation==='reverse'?depths.length-1-index:index];
     sorted.forEach((row,i)=>{if(Math.fround(row.depth)===depth)draw(mutation==='depthWrite'?badDepth:transparent,streamGroups[i]);});
   }};
   if(mutation==='tail'){
     bank.prepare([{lower:-1,upper:1,layer:null}]);bank.bind(pass,0);variable();
     for(let i=0;i<unique.length;i++)layers.drawGroup(pass,i);
   }else drawTransparencyBands(pass,bank,bands,layers,variable);
   if(witness){bank.bind(pass,0);draw(opaque,prepare({depth:.7,color:[1,1,0,1]},false));}
   pass.end();device.queue.submit([encoder.finish()]);
   const [color,identity,surface]=await Promise.all([read(scene.color,8),read(scene.identity,4),read(scene.surface,4)]);
   const data=new Uint16Array(color.buffer);
   const rgb=Array.from({length:scene.width},(_,x)=>[0,1,2].map(c=>half(data[(scene.width*4+x)*4+c])));
   return {rgb,identity:Array.from(new Uint32Array(identity.buffer)),surface:Array.from(new Float32Array(surface.buffer))};
 };
 const wall:Layer={depth:.3,color:[.25,0,0,.25]},stream:Layer={depth:.5,color:[0,.32,0,.32]};
 const assertions:{name:string;error:number}[]=[];
 const check=async(name:string,w:Layer|null,streams:Layer[],mutation:Mutation=null,witness=false)=>{
   const actual=await render(w,streams,mutation,witness);let error=0;
   for(let x=0;x<scene.width;x++){
     const layers=[...streams,...(w?[{...w,depth:Math.fround(w.depth)+((x+.5)/scene.width*2-1)*(w.slope??0)}]:[])];
     layers.sort((a,b)=>b.depth-a.depth);
     const expected=witness?[1,1,0,1]:layers.reduce((color,row)=>over(row.color,color),[0,0,1,1] as Color);
     for(let c=0;c<3;c++)error=Math.max(error,Math.abs(actual.rgb[x][c]-expected[c]));
   }
   if(mutation===null&&error>.0015)throw new Error(`${name}: color error ${error}`);
   if(mutation!==null&&error<.01)throw new Error(`${name}: defective mechanism was not detected`);
   assertions.push({name,error});return actual;
 };
 try{
   const baseline=await check('no water',wall,[]);
   const nearer=await check('nearer wall',wall,[stream]);
   if(JSON.stringify(baseline.identity)!==JSON.stringify(nearer.identity)||JSON.stringify(baseline.surface)!==JSON.stringify(nearer.surface))throw new Error('Transparent ownership changed.');
   await check('farther wall',{...wall,depth:.7},[stream]);
   await check('crossing wall',{...wall,depth:.5,slope:.2},[stream]);
   const multiple=[{depth:.8,color:[.12,.12,0,.12] as Color},stream,{depth:.2,color:[0,.1,.1,.1] as Color}];
   const first=await check('multiple streams',wall,multiple);
   const reversed=await check('input permutation',wall,[...multiple].reverse());
   if(JSON.stringify(first)!==JSON.stringify(reversed))throw new Error('Input order changed distinct-depth composition.');
   await check('exact boundary',{...wall,depth:.5},[stream]);
   await check('equal stream depths',wall,[stream,stream]);
   await check('mutant fixed tail',wall,[stream],'tail');
   await check('mutant missing clip',wall,[stream],'unclipped');
   await check('mutant overlapping bands',wall,[stream],'overlap');
   await check('mutant reversed streams',wall,multiple,'reverse');
   await check('mutant transparent depth writes',null,[stream],'depthWrite',true);
   await check('depth witness',null,[stream],null,true);
   // Compile the production water shader and exercise its actual retained resources.
   const program=device.createRenderPipeline(showerWaterPipelineDescriptor(device.createShaderModule({code:waterShader})));
   const thinStroke=await checkThinStroke(program);
   const effect=new ShowerWaterRenderer(device);
   try{effect.prepare([]);if(effect.groups.length)throw new Error('Empty shower has live water.');}finally{effect.destroy();effect.destroy();}
   await device.queue.onSubmittedWorkDone();if(errors.length)throw new Error(errors.join('\n'));
   const integration=await actualSprites();
   await device.queue.onSubmittedWorkDone();if(errors.length)throw new Error(errors.join('\n'));
   return {assertions,ownershipSamples:baseline.identity.length,productionWaterCompiled:!!program,thinStroke,integration,adapter:adapter.info.description};
 }finally{for(const resource of resources)resource.destroy();bank.destroy();scene.destroy();device.destroy();}

 async function checkThinStroke(program:GPURenderPipeline){
   const energies:number[]=[],buffer=device.createBuffer({size:54*4,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});
   try{
     bank.prepare([{lower:-1,upper:1,layer:null}]);
     for(let offset=0;offset<16;offset++){
       const center=offset/16,physicalHalf=.22,support=physicalHalf+.25,edge=support/physicalHalf;
       const corners=[[-support,.5,-edge,0],[support,.5,edge,0],[-support,-.5,-edge,1],[support,-.5,edge,1]];
       const data=new Float32Array([0,1,2,2,1,3].flatMap(i=>[(corners[i][0]+center)/16*2,corners[i][1],.5,.5,0,1,0,corners[i][2],corners[i][3]]));
       device.queue.writeBuffer(buffer,0,data);
       const encoder=device.createCommandEncoder(),pass=scene.begin(encoder);
       bank.bind(pass,0);pass.setPipeline(opaque);pass.setBindGroup(0,prepare({depth:.9,color:[0,0,1,1]},false));pass.draw(3);
       pass.setPipeline(program);pass.setVertexBuffer(0,buffer);pass.draw(6);pass.end();device.queue.submit([encoder.finish()]);
       const raw=await read(scene.color,8),values=new Uint16Array(raw.buffer);
       let energy=0;for(let i=1;i<values.length;i+=4)energy+=half(values[i]);energies.push(energy);
     }
     const minimum=Math.min(...energies),maximum=Math.max(...energies);
     if(minimum<=0||(maximum-minimum)/maximum>.003)throw new Error('Thin water disappears or changes coverage across sample columns.');
     return {registrations:energies.length,minimum,maximum,relativeVariation:(maximum-minimum)/maximum};
   }finally{buffer.destroy();}
 }

 async function actualSprites(){
   const canvas=document.createElement('canvas');canvas.width=320;canvas.height=240;document.body.append(canvas);
   const context=canvas.getContext('webgpu')!;context.configure({device,format:'rgba8unorm',alphaMode:'premultiplied'});
   const renderer=await SpriteRenderer.create({device,context,format:'rgba8unorm'}),water=new ShowerWaterRenderer(device);
   const empty=new Float32Array(),wall=new Float32Array(FLOATS_PER_INSTANCE);
   const nozzle=[1,0,0,0,0,-.8944285,.447211,0,0,-.447211,-.8944285,0,0,-.0755,1.709,1];
   const emitter={nozzle,phase:.19,angle:0,x:160,y:220,width:320,height:240,scale:3,depth:.5,step:.01,light:[1,1,1] as const};
   const captures:{name:string;maximumError:number;affectedSamples:number}[]=[];
   let background:Color=[0,0,0,1];
   // An opaque test plane supplies a known color and owner through the same world callback as the character meshes.
   const drawBackground=(pass:GPURenderPassEncoder)=>{pass.setPipeline(opaque);pass.setBindGroup(0,prepare({depth:.9,color:background},false));bank.bind(pass,0);pass.draw(3);};
   const capture=async(wallDepth:number|null,active:boolean,bg:0|1)=>{
     background=[bg,bg,bg,1];
     writeInstance(wall,0,160,220,wallDepth??.3,spriteIndex('wallLow15'),1,1,1,0,15,0);wall[10]=.25;wall[11]=26;
     renderer.setStaticGeometry(empty,0,wallDepth===null?empty:wall);
     renderer.draw(empty,0,3,undefined,0,drawBackground,undefined,undefined,active?water:undefined);
     const target=renderer.sceneForPicking;
     const [color,identity,surface]=await Promise.all([read(target.color,8),read(target.identity,4),read(target.surface,4)]);
     return {color:Array.from(new Uint16Array(color.buffer),half),identity,surface};
   };
   try{
     bank.prepare([{lower:-1,upper:1,layer:null}]);
     for(const angle of [0,Math.PI/2,Math.PI,Math.PI*1.5]){
       water.prepare([{...emitter,angle}]);
       const waterBlack=await capture(null,true,0),waterWhite=await capture(null,true,1);
       const alpha=waterBlack.color.map((value,index)=>index%4===3?0:1-waterWhite.color[index]+value);
       for(const wallDepth of [.3,.7]){
         const wallBlack=await capture(wallDepth,false,0),wallWhite=await capture(wallDepth,false,1);
         const combined=await capture(wallDepth,true,0);let maximumError=0,affectedSamples=0;
         for(let i=0;i<combined.color.length;i++){
           if(i%4===3)continue;
           const wallAlpha=1-wallWhite.color[i]+wallBlack.color[i];
           const expected=wallDepth<.5?wallBlack.color[i]+waterBlack.color[i]*(1-wallAlpha)
             :waterBlack.color[i]+wallBlack.color[i]*(1-alpha[i]);
           maximumError=Math.max(maximumError,Math.abs(combined.color[i]-expected));
           if(waterBlack.color[i]>.001&&wallAlpha>.1)affectedSamples++;
         }
         if(maximumError>.002||affectedSamples===0)throw new Error(`Actual SpriteRenderer composition failed: ${angle}/${wallDepth}, error ${maximumError}, overlap ${affectedSamples}`);
         if(combined.identity.some((v,i)=>v!==wallBlack.identity[i])||combined.surface.some((v,i)=>v!==wallBlack.surface[i]))throw new Error('Production water replaced physical ownership.');
         captures.push({name:`facing ${angle}, wall ${wallDepth}`,maximumError,affectedSamples});
       }
     }
     water.prepare([]);const cleared=await capture(null,true,0);
     if(cleared.color.some((v,i)=>i%4!==3&&v!==0))throw new Error('Inactive shower still renders water.');
     return {captures,groups:water.groups.length,allocatedBytes:water.allocatedBytes};
   }finally{water.destroy();renderer.destroy();context.unconfigure();}
 }
}
(window as unknown as {waterProof:Promise<unknown>}).waterProof=run().then(result=>{
 document.querySelector('#results')!.textContent=JSON.stringify(result,null,2);return result;
}).catch(error=>{document.querySelector('#results')!.textContent=String(error);throw error;});
