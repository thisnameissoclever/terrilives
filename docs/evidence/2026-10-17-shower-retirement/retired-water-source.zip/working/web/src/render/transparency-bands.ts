export interface DepthGroup {depth:number;first:number;count:number}
export interface TransparentLayers {
  readonly groups:readonly DepthGroup[];
  drawGroup(pass:GPURenderPassEncoder,index:number):void;
}
export interface DepthBand {lower:number;upper:number;layer:number|null}

/** Larger depth is farther away. Equal-depth walls draw after the stream. */
export function transparencyBands(depths:readonly number[]):DepthBand[]{
  const result:DepthBand[]=[];
  let upper=1;
  depths.forEach((value,index)=>{
    const depth=Math.fround(value);
    if(!Number.isFinite(depth)||depth<0||depth>1||(index>0&&depth>=upper))throw new Error('Transparent layers must have distinct descending depths.');
    result.push({lower:depth,upper,layer:index});upper=depth;
  });
  result.push({lower:-1,upper,layer:null});
  return result;
}

/** Validate constant-depth quads using the exact values sent to the graphics device. */
export function constantDepthGroups(vertices:Float32Array):DepthGroup[]{
  if(vertices.length%54!==0)throw new Error('Transparent stream data must contain complete quads.');
  const groups:DepthGroup[]=[];
  for(let first=0;first<vertices.length/9;first+=6){
    const depth=vertices[first*9+2];
    if(!Number.isFinite(depth)||depth<0||depth>1)throw new Error('Invalid transparent stream depth.');
    for(let i=1;i<6;i++)if(vertices[(first+i)*9+2]!==depth)throw new Error('Transparent stream must have constant depth.');
    const last=groups.at(-1);
    if(last&&depth>last.depth)throw new Error('Transparent streams are not sorted farthest first.');
    if(last?.depth===depth)last.count+=6;
    else groups.push({depth,first,count:6});
  }
  return groups;
}

export const transparencyBandShader=`
struct TransparencyBand { lower:f32, upper:f32, padding:vec2f };
@group(1) @binding(0) var<uniform> transparencyBand:TransparencyBand;
fn outsideTransparencyBand(depth:f32)->bool {
  return depth<=transparencyBand.lower || depth>transparencyBand.upper;
}`;

export function drawTransparencyBands(pass:GPURenderPassEncoder,bank:TransparencyBandBuffer,
  bands:readonly DepthBand[],layers:TransparentLayers|undefined,drawVariable:(index:number)=>void):void {
  for(let index=0;index<bands.length;index++){
    bank.bind(pass,index);drawVariable(index);
    const layer=bands[index].layer;
    if(layer!==null)layers!.drawGroup(pass,layer);
  }
}

/** Every draw uses a separate aligned record; queued writes cannot change earlier bands. */
export class TransparencyBandBuffer {
  readonly layout:GPUBindGroupLayout;
  private buffer:GPUBuffer|null=null;
  private group:GPUBindGroup|null=null;
  private capacity=0;
  private readonly stride:number;
  constructor(private readonly device:GPUDevice){
    this.stride=device.limits.minUniformBufferOffsetAlignment;
    this.layout=device.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.FRAGMENT,
      buffer:{type:'uniform',hasDynamicOffset:true,minBindingSize:16}}]});
  }
  prepare(bands:readonly DepthBand[]):void {
    const bytes=bands.length*this.stride;
    if(bytes>this.device.limits.maxBufferSize)throw new Error('Transparent depth bands exceed the graphics buffer limit.');
    if(bytes>this.capacity){
      const next=this.device.createBuffer({size:bytes,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});
      this.buffer?.destroy();this.buffer=next;this.capacity=bytes;
      this.group=this.device.createBindGroup({layout:this.layout,entries:[{binding:0,resource:{buffer:next,size:16}}]});
    }
    const data=new Float32Array(bytes/4);
    bands.forEach((band,index)=>{data[index*this.stride/4]=band.lower;data[index*this.stride/4+1]=band.upper;});
    if(bytes)this.device.queue.writeBuffer(this.buffer!,0,data);
  }
  bind(pass:GPURenderPassEncoder,index:number):void{
    if(!this.group||index<0||(index+1)*this.stride>this.capacity)throw new Error('Transparent depth band is not prepared.');
    pass.setBindGroup(1,this.group,[index*this.stride]);
  }
  destroy():void{this.buffer?.destroy();this.buffer=null;this.group=null;this.capacity=0;}
}
