import {transform,type Vec3} from './math.js';
export interface ShowerWaterEmitter {
  nozzle:readonly number[];phase:number;angle:number;x:number;y:number;width:number;height:number;
  scale:number;depth:number;step:number;light:Vec3;
}
export interface WaterSegment {start:Vec3;end:Vec3;stream:number;slot:number}
export function activeShowerWater(clip:string,model:string|null,sample:number,count:number,
  prop:{matrix:readonly number[];visible:boolean;owner?:string}|undefined):{nozzle:readonly number[];phase:number}|null {
  if(clip!=='shower')return null;
  if(model!=='shower'||!prop||prop.owner!=='fixture'||!prop.visible||!Number.isFinite(sample)
    ||!Number.isInteger(count)||count<=0)throw new Error('Active shower has no registered fixture nozzle.');
  return {nozzle:prop.matrix,phase:sample/count};
}
const FLOOR=.057;
const STREAMS=8;
const DASH=.105;

/** Droplet positions follow the nozzle direction and gravity; each short streak is vertical. */
export function showerWaterSegments(nozzle:readonly number[],phase:number):WaterSegment[]{
  if(nozzle.length!==16||!nozzle.every(Number.isFinite)||!Number.isFinite(phase)
    ||nozzle[3]!==0||nozzle[7]!==0||nozzle[11]!==0||nozzle[15]!==1||nozzle[10]>=-.3
    ||nozzle[14]<=FLOOR+.15)throw new Error('Invalid shower nozzle registration.');
  const rows:WaterSegment[]=[];
  const time=((phase%1)+1)%1;
  for(let stream=0;stream<STREAMS;stream++){
    const angle=stream*2*Math.PI/STREAMS;
    const origin=transform(nozzle,[.065*Math.cos(angle),.065*Math.sin(angle),.004]);
    if(Math.abs(origin[0])>.34||Math.abs(origin[1])>.34)throw new Error('Shower spray leaves the recessed tray.');
    const travel=origin[2]-FLOOR+DASH;
    const across=.45*Math.cos(angle),vertical=-.125*(1+Math.sin(angle));
    const norm=Math.hypot(across,vertical,1),speed=.8,gravity=9.81;
    const velocity=[0,1,2].map(i=>(nozzle[i]*across+nozzle[4+i]*vertical+nozzle[8+i])*speed/norm);
    const down=-velocity[2];
    const lifetime=(Math.sqrt(down*down+2*gravity*travel)-down)/gravity;
    for(let slot=0;slot<3;slot++){
      const progress=(time+stream*.618033988749895+slot/3)%1;
      const age=progress*lifetime;
      const top=origin[2]+DASH-down*age-.5*gravity*age*age;
      const start=Math.min(origin[2],top),end=Math.max(FLOOR,top-DASH);
      if(start<=end)continue;
      const x=origin[0]+velocity[0]*age,y=origin[1]+velocity[1]*age;
      if(Math.abs(x)>.34||Math.abs(y)>.34)throw new Error('Falling shower water leaves the recessed tray.');
      rows.push({start:[x,y,start],end:[x,y,end],stream,slot});
    }
  }
  return rows;
}

const linear=(v:number)=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4;

/** Use the same source-to-world projection and physical depth as character meshes. */
export function projectShowerWater(emitters:readonly ShowerWaterEmitter[]):Float32Array<ArrayBuffer>{
  const quads:{depth:number;values:number[]}[]=[];
  for(const emitter of emitters){
    const {angle,x,y,width,height,scale,depth,step,light}=emitter;
    if(![angle,x,y,width,height,scale,depth,step,...light].every(Number.isFinite)
      ||width<=0||height<=0||scale<=0||step<=0||light.some(v=>v<0))throw new Error('Invalid shower view registration.');
    const c=Math.cos(angle),s=Math.sin(angle);
    const color=[.35,.68,.93].map((value,i)=>linear(Math.min(1,value*light[i])));
    const point=(p:Vec3):[number,number,number]=>{
      const rx=c*p[0]-s*p[1],ry=s*p[0]+c*p[1];
      return [(x+(rx+ry)*32*scale)/width*2-1,
        1-(y+((rx-ry)*21-p[2]*Math.sqrt(1166))*scale)/height*2,
        Math.max(0,Math.min(1,depth-(rx-ry)*step))];
    };
    for(const row of showerWaterSegments(emitter.nozzle,emitter.phase)){
      const a=point(row.start),b=point(row.end),physicalHalfWidth=.22*scale;
      // Half a physical scene sample extends raster support without increasing stroke energy.
      const halfWidth=(physicalHalfWidth+.25)/width*2,edge=(physicalHalfWidth+.25)/physicalHalfWidth;
      const corners=[[a[0]-halfWidth,a[1],a[2],-edge,0],[a[0]+halfWidth,a[1],a[2],edge,0],
        [b[0]-halfWidth,b[1],b[2],-edge,1],[b[0]+halfWidth,b[1],b[2],edge,1]];
      const values:number[]=[];
      for(const index of [0,1,2,2,1,3]){
        const vertex=corners[index];values.push(vertex[0],vertex[1],vertex[2],.5,...color,vertex[3],vertex[4]);
      }
      quads.push({depth:a[2],values});
    }
  }
  // Transparent contributions are drawn farthest first, including separate showers.
  quads.sort((a,b)=>b.depth-a.depth);
  return new Float32Array(quads.flatMap(row=>row.values));
}
