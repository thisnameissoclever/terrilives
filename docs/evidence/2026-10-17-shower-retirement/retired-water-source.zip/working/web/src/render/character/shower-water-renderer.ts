import {SCENE_COLOR_FORMAT,SCENE_IDENTITY_FORMAT,SCENE_SURFACE_FORMAT} from '../scene-sampling.js';
import {projectShowerWater,type ShowerWaterEmitter} from './shower-water.js';
import {releaseCharacterOnDeviceLoss} from './resources.js';
import shader from './shower-water.wgsl?raw';
import {constantDepthGroups,type DepthGroup,type TransparentLayers} from '../transparency-bands.js';

export function showerWaterPipelineDescriptor(module:GPUShaderModule):GPURenderPipelineDescriptor {
  const blend:GPUBlendComponent={srcFactor:'one',dstFactor:'one-minus-src-alpha',operation:'add'};
  return {layout:'auto',vertex:{module,entryPoint:'vertex',buffers:[{arrayStride:36,attributes:[
    {shaderLocation:0,offset:0,format:'float32x3'},{shaderLocation:1,offset:12,format:'float32'},
    {shaderLocation:2,offset:16,format:'float32x3'},{shaderLocation:3,offset:28,format:'float32x2'}]}]},
    fragment:{module,entryPoint:'fragment',targets:[{format:SCENE_COLOR_FORMAT,blend:{color:blend,alpha:blend}},
      {format:SCENE_SURFACE_FORMAT,writeMask:0},{format:SCENE_IDENTITY_FORMAT,writeMask:0}]},
    primitive:{topology:'triangle-list'},depthStencil:{format:'depth24plus',depthWriteEnabled:false,depthCompare:'less-equal'}};
}

const programs=new WeakMap<GPUDevice,GPURenderPipeline>();

/** One retained stream buffer for the world's active showers; no per-frame graphics allocation. */
export class ShowerWaterRenderer implements TransparentLayers {
  private buffer:GPUBuffer|null=null;
  private count=0;
  groups:readonly DepthGroup[]=[];
  private closed=false;
  private readonly forgetLoss:()=>void;
  private readonly pipeline:GPURenderPipeline;
  constructor(private readonly device:GPUDevice){
    let pipeline=programs.get(device);
    if(!pipeline){
      pipeline=device.createRenderPipeline(showerWaterPipelineDescriptor(device.createShaderModule({code:shader})));
      programs.set(device,pipeline);void device.lost.then(()=>programs.delete(device));
    }
    this.pipeline=pipeline;this.forgetLoss=releaseCharacterOnDeviceLoss(device,()=>this.destroy());
  }
  prepare(emitters:readonly ShowerWaterEmitter[]):void {
    if(this.closed)throw new Error('Shower water renderer is closed.');
    const data=projectShowerWater(emitters);
    this.groups=constantDepthGroups(data);
    if(data.byteLength>this.device.limits.maxBufferSize)throw new Error('Shower water exceeds the graphics buffer limit.');
    if(data.byteLength>(this.buffer?.size??0)){
      let size=256;while(size<data.byteLength)size*=2;
      const next=this.device.createBuffer({size:Math.min(size,this.device.limits.maxBufferSize),usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});
      this.buffer?.destroy();this.buffer=next;
    }
    this.count=data.length/9;
    if(this.count)this.device.queue.writeBuffer(this.buffer!,0,data);
  }
  drawGroup(pass:GPURenderPassEncoder,index:number):void {
    if(!this.count||this.closed)return;
    const group=this.groups[index];
    if(!group)throw new Error('Shower water depth group is missing.');
    pass.setPipeline(this.pipeline);pass.setVertexBuffer(0,this.buffer!);pass.draw(group.count,1,group.first);
  }
  get allocatedBytes():number{return this.buffer?.size??0;}
  destroy():void{if(this.closed)return;this.closed=true;this.count=0;this.groups=[];this.buffer?.destroy();this.buffer=null;this.forgetLoss();}
}
