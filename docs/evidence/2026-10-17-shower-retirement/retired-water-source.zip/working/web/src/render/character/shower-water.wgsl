struct WaterVertex {
  @builtin(position) position:vec4f,
  @location(0) opacity:f32,
  @location(1) color:vec3f,
  @location(2) uv:vec2f,
};
@vertex fn vertex(@location(0) position:vec3f,@location(1) opacity:f32,
                 @location(2) color:vec3f,@location(3) uv:vec2f)->WaterVertex {
  var out:WaterVertex;out.position=vec4f(position,1.);out.opacity=opacity;out.color=color;out.uv=uv;return out;
}
@fragment fn fragment(in:WaterVertex)->@location(0) vec4f {
  let radius=max(.00001,.5*fwidth(in.uv.x));
  let sides=clamp(min(1.,in.uv.x+radius)-max(-1.,in.uv.x-radius),0.,2.*radius)/(2.*radius);
  let ends=smoothstep(0.,.14,in.uv.y)*(1.-smoothstep(.86,1.,in.uv.y));
  let alpha=in.opacity*sides*ends;
  return vec4f(in.color*alpha,alpha);
}
