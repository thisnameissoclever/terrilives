const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const {execFileSync}=require('node:child_process');
const root=path.resolve(__dirname,'..');
const modulePath=process.env.PLAYWRIGHT_MODULE;
if(!modulePath)throw new Error('Set PLAYWRIGHT_MODULE to an existing Playwright module. This check installs nothing.');
const {chromium}=require(modulePath);
const base=process.env.TERRI_PROOF_URL||'http://127.0.0.1:5191';
const output=path.resolve(root,process.env.TERRI_WATER_EVIDENCE||'.local-build/shower-water');
const capture=path.resolve(os.homedir(),'.codex/tmp/playwright-mcp/shower-water');
const files=['web/src/render/transparency-bands.ts','web/src/render/sprites.ts','web/src/render/sprites.wgsl',
 'web/src/render/character/shower-water.ts','web/src/render/character/shower-water-renderer.ts',
 'web/src/render/character/shower-water.wgsl','web/src/render/character/world.ts','web/proofs/shower-water.ts'];
const hashes=()=>Object.fromEntries(files.map(file=>[file,crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex')]));
const assert=(test,message)=>{if(!test)throw new Error(message);};
(async()=>{
 fs.mkdirSync(output,{recursive:true});fs.mkdirSync(capture,{recursive:true});
 const before=hashes(),browser=await chromium.launch({headless:true,channel:'chrome'});
 const report={base,head:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),sourceHashes:before,started:new Date().toISOString(),checks:[],errors:[]};
 try{
  const proof=await browser.newContext();
  try{const page=await proof.newPage();await page.goto(`${base}/proofs/shower-water.html`);
   await page.waitForFunction(()=>!document.querySelector('#results').textContent.startsWith('Running'),{},{timeout:60000});
   report.graphics=JSON.parse(await page.locator('#results').innerText());
  }finally{await proof.close();}
  for(let facing=0;facing<4;facing++){
   const context=await browser.newContext({viewport:{width:1280,height:900}});
   try{
    const page=await context.newPage();page.setDefaultTimeout(15000);page.on('pageerror',error=>report.errors.push(error.message));
    await page.goto(`${base}/?stress=0`);await page.waitForFunction(()=>!!window.__terriStress,{},{timeout:60000});
    await page.getByRole('button',{name:'Got it',exact:true}).click();await page.locator('label[for="speed-0"]').click();
    await page.locator('#options-toggle').click();await page.locator('#lighting-mode').click();await page.locator('#options-close').click();
    const state=await page.evaluate(facing=>{
     const s=window.__terriStress,sim=s.sim;
     const fixture=Array.from(sim.ids()).find(id=>sim.objectModel(id)?.id==='shower'),person=Array.from(sim.ids()).find(id=>sim.simName(id)==='Tim');
     if(fixture===undefined||person===undefined)throw new Error('Shower study resources are missing.');
     if(!sim.placeObject(fixture,14,6,facing))throw new Error('Shower rotation command failed.');sim.flushCommands();
     if(sim.lastPlacementResult()?.reason)throw new Error(sim.lastPlacementResult().reason);
     const interaction=sim.objectModel(fixture).actions.findIndex(action=>action.id==='take_shower');
     if(!sim.useObjectFirst(person,fixture,interaction))throw new Error('Shower command failed.');sim.flushCommands();
     let ticks=0;for(;ticks<400;ticks++){sim.tick();if(sim.activities()[sim.ids().indexOf(person)]===12)break;}
     if(ticks===400)throw new Error('Shower did not start.');s.step(performance.now());
     const snapshot=s.characters.snapshot(),actor=snapshot.actors.find(a=>a.entity===person);
     if(actor?.clip!=='shower'||actor.fixture!==fixture||snapshot.showerWater.groups===0)throw new Error('Active shower has no owned water.');
     return {fixture,person,facing,ticks,angle:actor.angle,water:snapshot.showerWater,view:snapshot.view};
    },facing);
    report.checks.push(state);
    const save=async name=>{const temp=path.join(capture,name);await page.screenshot({path:temp});fs.copyFileSync(temp,path.join(output,name));};
    await save(`facing-${facing}-native.png`);
    // Inspect one full motion cycle as sampled stills, not a claim of continuous video review.
    if(facing===1)for(let phase=0;phase<8;phase++){
     await save(`motion-${phase}.png`);
     await page.evaluate(()=>{const s=window.__terriStress;for(let i=0;i<3;i++)s.sim.tick();s.step(performance.now());});
    }
    await page.mouse.move(832,648);await page.mouse.wheel(0,-1200);await page.waitForTimeout(100);await save(`facing-${facing}-large.png`);
    const held=await page.evaluate(()=>{const s=window.__terriStress,a=s.characters.snapshot();for(let i=0;i<10;i++)s.step(performance.now());const b=s.characters.snapshot();return {a:a.actors.find(row=>row.clip==='shower')?.sample,b:b.actors.find(row=>row.clip==='shower')?.sample,water:b.showerWater};});
    assert(held.a===held.b,'Paused shower phase changed.');
    const exit=await page.evaluate(({person})=>{const s=window.__terriStress,sim=s.sim;const toilet=Array.from(sim.ids()).find(id=>sim.objectModel(id)?.id==='toilet');
     sim.useObjectFirst(person,toilet,0);sim.flushCommands();for(let i=0;i<100;i++){sim.tick();if(sim.activities()[sim.ids().indexOf(person)]!==12)break;}s.step(performance.now());return s.characters.snapshot().showerWater;
    },state);
    assert(exit.groups===0,'Shower water survived leaving the shower.');
    report.checks.push({facing,held,exit});
   }finally{await context.close();}
  }
  assert(report.errors.length===0,report.errors.join('\n'));
  assert(JSON.stringify(before)===JSON.stringify(hashes()),'Source changed while graphics checks were running.');
  report.status='PASS';
 }catch(error){report.status='FAIL';report.failure=String(error);throw error;}
 finally{await browser.close();fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');}
 console.log(JSON.stringify({status:report.status,output,facings:4}));
})().catch(error=>{console.error(error);process.exitCode=1;});
