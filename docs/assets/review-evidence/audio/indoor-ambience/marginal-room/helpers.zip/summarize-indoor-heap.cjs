const fs = require('node:fs');
const path = require('node:path');
const directory = path.join(__dirname, 'indoor-ambience', process.argv[2] ?? 'heap-diagnostic');
function summarize(file) {
  const snapshot = JSON.parse(fs.readFileSync(path.join(directory, file), 'utf8'));
  const fields = snapshot.snapshot.meta.node_fields;
  const stride = fields.length;
  const types = snapshot.snapshot.meta.node_types[fields.indexOf('type')];
  const names = snapshot.strings;
  const byGroup = new Map();
  for (let index = 0; index < snapshot.nodes.length; index += stride) {
    const type = types[snapshot.nodes[index + fields.indexOf('type')]];
    const name = names[snapshot.nodes[index + fields.indexOf('name')]];
    const key = `${type}: ${name}`;
    const value = byGroup.get(key) ?? { count: 0, bytes: 0 };
    value.count++;
    value.bytes += snapshot.nodes[index + fields.indexOf('self_size')];
    byGroup.set(key, value);
  }
  return byGroup;
}
const report = { diagnosticOnly: true, modes: {} };
for (const mode of process.argv.length > 3 ? process.argv.slice(3) : ['enabled', 'disabled']) {
  const before = summarize(`${mode}-baseline.heapsnapshot`);
  const after = summarize(`${mode}-final.heapsnapshot`);
  const deltas = [...new Set([...before.keys(), ...after.keys()])].map(key => ({
    key, countBefore: before.get(key)?.count ?? 0, countAfter: after.get(key)?.count ?? 0,
    countDelta: (after.get(key)?.count ?? 0) - (before.get(key)?.count ?? 0),
    byteDelta: (after.get(key)?.bytes ?? 0) - (before.get(key)?.bytes ?? 0),
  }));
  const byType = {};
  for (const item of deltas) {
    const type = item.key.slice(0, item.key.indexOf(':'));
    const value = byType[type] ?? {bytes: 0, count: 0};
    value.bytes += item.byteDelta; value.count += item.countDelta; byType[type] = value;
  }
  report.modes[mode] = { byType, largestGrowth: deltas.sort((a, b) => b.byteDelta - a.byteDelta).slice(0, 35),
    audio: deltas.filter(item => /Audio|BufferSource|RoomAmbience|GainNode|Oscillator|room|ambience|onended/i.test(item.key)).slice(0, 100) };
}
fs.writeFileSync(path.join(directory, 'ownership-summary.json'), JSON.stringify(report, null, 2) + '\n');
for (const [mode, value] of Object.entries(report.modes)) {
  console.log(mode, JSON.stringify(value.byType));
  console.log(value.largestGrowth.slice(0, 18));
  console.log(value.audio.filter(item => item.countDelta !== 0 || /object:.*(Audio|Gain|Buffer)/.test(item.key)));
}
