function seedAudioPreferences({origin, ambienceLevel}) {
  if (location.origin !== origin) return;
  localStorage.setItem('terrilives.audio-preferences.v1', JSON.stringify({
    version: 1, muted: false, effectsLevel: 0.7, voicesLevel: 1, ambienceLevel,
  }));
}
module.exports = {seedAudioPreferences};
