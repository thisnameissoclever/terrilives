const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { finished } = require('node:stream/promises');
const { chromium } = require(path.join(process.env.APPDATA, 'npm/node_modules/@playwright/cli/node_modules/playwright-core'));
const output = path.join(__dirname, 'indoor-ambience', 'marginal-room-diagnostic-01');
if (fs.existsSync(output)) throw new Error('Refusing to overwrite an existing diagnostic');
fs.mkdirSync(output, {recursive: true});
const harnessPath = path.resolve('scripts/audio-browser-proof.cjs');
const isolated = {exports: {}};
vm.runInNewContext(fs.readFileSync(harnessPath, 'utf8') + '\nmodule.exports.runDiagnostic = runMemory;',
  {require, module: isolated, exports: isolated.exports, process, console, URL, setTimeout, clearTimeout},
  {filename: harnessPath});

async function main() {
  const browser = await chromium.launch({channel: 'chrome', headless: false,
    args: ['--window-position=0,0', '--window-size=1400,900', '--enable-blink-features=ForceEagerMeasureMemory']});
  const report = {diagnosticOnly: true, acceptanceClaimed: false, generatedAt: new Date().toISOString(),
    allAudioSamplingEnabled: true, build: 'index-ChVIKHes.js', runs: [], snapshots: [], pageErrors: []};
  try {
    for (const ambienceLevel of [0.25, 0]) {
      const label = ambienceLevel ? 'room-25' : 'room-0';
      const instrumented = {newContext: async options => {
        const context = await browser.newContext(options);
        await context.addInitScript(level => localStorage.setItem('terrilives.audio-preferences.v1', JSON.stringify({
          version: 1, muted: false, effectsLevel: 0.7, voicesLevel: 1, ambienceLevel: level,
        })), ambienceLevel);
        context.on('page', page => page.on('pageerror', error => report.pageErrors.push(String(error))));
        const originalSession = context.newCDPSession.bind(context);
        context.newCDPSession = async page => {
          const cdp = await originalSession(page), send = cdp.send.bind(cdp);
          let sample = 0;
          cdp.send = async (method, ...args) => {
            const result = await send(method, ...args);
            if (method === 'Runtime.getHeapUsage') {
              const index = sample++;
              if (index === 0 || index === 9) {
                const file = `${label}-${index === 0 ? 'baseline' : 'final'}.heapsnapshot`;
                const stream = fs.createWriteStream(path.join(output, file), {flags: 'wx'});
                const hash = crypto.createHash('sha256');
                const chunk = event => {stream.write(event.chunk); hash.update(event.chunk);};
                cdp.on('HeapProfiler.addHeapSnapshotChunk', chunk);
                try {await send('HeapProfiler.takeHeapSnapshot', {reportProgress: false, captureNumericValue: true});}
                finally {cdp.off('HeapProfiler.addHeapSnapshotChunk', chunk); stream.end(); await finished(stream);}
                report.snapshots.push({label, file, sha256: hash.digest('hex'),
                  audio: await page.evaluate(() => ({...globalThis.__terriStress.audio})),
                  preferences: await page.evaluate(() => JSON.parse(localStorage.getItem('terrilives.audio-preferences.v1')))});
                console.log(`Captured ${file}`);
              }
            }
            return result;
          };
          return cdp;
        };
        return context;
      }};
      const run = await isolated.exports.runDiagnostic(instrumented, 'http://127.0.0.1:5221/', true, 0);
      report.runs.push({ambienceLevel, ...run});
    }
    assert.equal(report.snapshots.length, 4);
    assert.deepEqual(report.pageErrors, []);
    const [on, off] = report.runs;
    for (const index of [0, 9]) {
      assert.equal(on.samples[index].worldHash, off.samples[index].worldHash);
      assert.equal(on.samples[index].tick, index === 0 ? 60 : 600);
      assert.equal(off.samples[index].tick, on.samples[index].tick);
      for (const run of report.runs) assert.equal(run.samples[index].retainedAmbienceVoices, 0);
    }
    for (const run of report.runs) {
      assert.ok(run.samples.some(sample => sample.footstepTracks > 0));
      assert.ok(run.samples.some(sample => sample.objectLoopVoices > 0));
      assert.ok(run.samples.some(sample => sample.doorVoices > 0));
    }
    assert.ok(on.samples.at(-1).ambienceStarts > 0);
    assert.ok(off.samples.every(sample => sample.ambienceStarts === 0));
    for (const snapshot of report.snapshots) {
      assert.equal(snapshot.preferences.ambienceLevel, snapshot.label === 'room-25' ? 0.25 : 0);
    }
    const growth = run => run.samples.at(-1).jsUsedBytes - run.samples[0].jsUsedBytes;
    report.comparable = true;
    report.roomOnGrowthBytes = growth(on);
    report.roomOffGrowthBytes = growth(off);
    report.marginalDifferenceBytes = growth(on) - growth(off);
  } catch (error) {
    report.error = String(error.stack ?? error);
    throw error;
  } finally {
    await browser.close();
    fs.writeFileSync(path.join(output, 'diagnostic.json'), JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
  }
  console.log(JSON.stringify({comparable: report.comparable, roomOnGrowthBytes: report.roomOnGrowthBytes,
    roomOffGrowthBytes: report.roomOffGrowthBytes, marginalDifferenceBytes: report.marginalDifferenceBytes}));
}
main().catch(error => {console.error(error); process.exitCode = 1;});
