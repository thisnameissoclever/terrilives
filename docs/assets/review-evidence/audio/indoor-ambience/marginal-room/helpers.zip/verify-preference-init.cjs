const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {chromium} = require(path.join(process.env.APPDATA, 'npm/node_modules/@playwright/cli/node_modules/playwright-core'));
const {seedAudioPreferences} = require('./seed-audio-preferences.cjs');
const origin = 'http://127.0.0.1:5221';
async function main() {
  const browser = await chromium.launch({channel: 'chrome', headless: false});
  const report = {generatedAt: new Date().toISOString(), tests: []};
  try {
    for (const guarded of [false, true]) {
      const context = await browser.newContext();
      const errors = [];
      try {
        context.on('page', page => page.on('pageerror', error => errors.push({url: page.url(), message: String(error)})));
        if (guarded) await context.addInitScript(seedAudioPreferences, {origin, ambienceLevel: 0.25});
        else await context.addInitScript(() => localStorage.setItem('terrilives.audio-preferences.v1', '{}'));
        await context.route(`${origin}/init-test`, route => route.fulfill({contentType: 'text/html', body: '<title>Preference initialization fixture</title>'}));
        const page = await context.newPage();
        await page.waitForTimeout(100);
        const blankErrors = [...errors];
        await page.goto(`${origin}/init-test`);
        const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('terrilives.audio-preferences.v1')));
        if (guarded) {
          assert.deepEqual(errors, []);
          assert.deepEqual(saved, {version: 1, muted: false, effectsLevel: 0.7, voicesLevel: 1, ambienceLevel: 0.25});
        } else {
          assert.equal(blankErrors.length, 1);
          assert.equal(blankErrors[0].url, 'about:blank');
          assert.match(blankErrors[0].message, /SecurityError.*localStorage/);
          assert.deepEqual(saved, {});
        }
        report.tests.push({guarded, blankErrors, errors, saved, pass: true});
      } finally {await context.close();}
    }
    report.pass = true;
  } finally {
    await browser.close();
    fs.writeFileSync(path.join(__dirname, 'indoor-ambience', 'marginal-room-diagnostic-01', 'preference-init-regression.json'),
      JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
  }
  console.log(JSON.stringify(report, null, 2));
}
main().catch(error => {console.error(error); process.exitCode = 1;});
