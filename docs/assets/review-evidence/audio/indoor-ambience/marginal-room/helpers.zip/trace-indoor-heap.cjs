const fs = require('node:fs');
const path = require('node:path');
const directory = path.join(__dirname, 'indoor-ambience', process.argv[2] ?? 'heap-diagnostic');
const load = name => JSON.parse(fs.readFileSync(path.join(directory, name), 'utf8'));
const before = load(`${process.argv[3] ?? 'enabled-baseline'}.heapsnapshot`);
const snapshot = load(`${process.argv[4] ?? 'enabled-final'}.heapsnapshot`);
const fields = snapshot.snapshot.meta.node_fields, stride = fields.length;
const edgeFields = snapshot.snapshot.meta.edge_fields, edgeStride = edgeFields.length;
const nodeTypes = snapshot.snapshot.meta.node_types[fields.indexOf('type')];
const edgeTypes = snapshot.snapshot.meta.edge_types[edgeFields.indexOf('type')];
const node = offset => ({offset, id: snapshot.nodes[offset + fields.indexOf('id')],
  type: nodeTypes[snapshot.nodes[offset + fields.indexOf('type')]],
  name: snapshot.strings[snapshot.nodes[offset + fields.indexOf('name')]],
  bytes: snapshot.nodes[offset + fields.indexOf('self_size')]});
const priorIds = new Set();
for (let offset = 0; offset < before.nodes.length; offset += stride) priorIds.add(before.nodes[offset + fields.indexOf('id')]);
const incoming = new Map();
let edgeOffset = 0;
for (let offset = 0; offset < snapshot.nodes.length; offset += stride) {
  const count = snapshot.nodes[offset + fields.indexOf('edge_count')];
  for (let index = 0; index < count; index++, edgeOffset += edgeStride) {
    const type = edgeTypes[snapshot.edges[edgeOffset + edgeFields.indexOf('type')]];
    if (type === 'weak') continue;
    const target = snapshot.edges[edgeOffset + edgeFields.indexOf('to_node')];
    const rawName = snapshot.edges[edgeOffset + edgeFields.indexOf('name_or_index')];
    const label = type === 'element' || type === 'hidden' ? String(rawName) : snapshot.strings[rawName];
    const parents = incoming.get(target) ?? [];
    parents.push({offset, type, label}); incoming.set(target, parents);
  }
}
function pathToRoot(target) {
  const queue = [{offset: target, path: []}], visited = new Set([target]);
  for (let index = 0; index < queue.length && index < 40000; index++) {
    const current = queue[index];
    if (current.offset === 0) return current.path;
    for (const edge of incoming.get(current.offset) ?? []) {
      if (visited.has(edge.offset)) continue;
      visited.add(edge.offset);
      queue.push({offset: edge.offset, path: [...current.path, {parent: node(edge.offset), edge: `${edge.type}:${edge.label}`, child: node(current.offset)}]});
    }
  }
  return [{unresolved: true}];
}
const targets = [];
for (let offset = 0; offset < snapshot.nodes.length; offset += stride) {
  const value = node(offset);
  if (!priorIds.has(value.id) && (value.name === 'AudioBuffer' || value.name === 'system / InstructionStream' ||
    (process.argv[5] === 'ownership' && (value.type === 'array' || value.type === 'closure' ||
      value.type === 'object' && value.name === 'Object')))) targets.push(value);
}
const selected = process.argv[5] === 'ownership'
  ? [...targets.filter(value => value.type === 'object' || value.type === 'closure' || value.name === 'AudioBuffer'),
    ...targets.filter(value => value.type === 'array').sort((a, b) => b.bytes - a.bytes).slice(0, 12)]
  : [...targets.filter(value => value.name === 'AudioBuffer'),
  ...targets.filter(value => value.name === 'system / InstructionStream').sort((a, b) => b.bytes - a.bytes).slice(0, 3)];
const report = selected.map(target => ({target, retainingPath: pathToRoot(target.offset)}));
fs.writeFileSync(path.join(directory, process.argv[6] ?? 'retaining-paths.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report.map(item => ({target: item.target, owners: item.retainingPath.slice(0, 5).map(edge => ({
  name: edge.parent?.name, type: edge.parent?.type, edge: edge.edge
}))})), null, 2));
