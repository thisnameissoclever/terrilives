const fs = require('node:fs');
const path = require('node:path');
const { closeHelpAndSetThreeTimes } = require('../scripts/audio-browser-proof.cjs');

async function main() {
  const baseUrl = process.argv[2] ?? 'http://127.0.0.1:5221/';
  const output = process.argv[3] ?? '.tmp/paused-hud-node-identity.json';
  const configured = process.env.TERRILIVES_PLAYWRIGHT_CORE;
  const core = configured ?? path.join(process.env.APPDATA, 'npm', 'node_modules', '@playwright', 'cli', 'node_modules', 'playwright-core');
  const { chromium } = require(core);
  const browser = await chromium.launch({ channel: 'chrome', headless: false });
  const context = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  let report;
  try {
    const page = await context.newPage();
    const url = new URL(baseUrl);
    url.searchParams.set('stress', '1000');
    url.searchParams.set('audio', '0');
    await page.goto(url.toString(), { waitUntil: 'networkidle' });
    await page.bringToFront();
    await page.waitForFunction(() => globalThis.__terriStress?.entities === 1037);
    await closeHelpAndSetThreeTimes(page);
    const start = await page.evaluate(() => globalThis.__terriStress.sim.clockTick());
    await page.waitForFunction(start => globalThis.__terriStress.sim.clockTick() - start >= 60, start);
    const selected = await page.evaluate(() => {
      const speed = document.querySelector('#speed-0');
      speed.checked = true;
      speed.dispatchEvent(new Event('change', { bubbles: true }));
      const sim = globalThis.__terriStress.sim;
      const selected = sim.selectedIndex();
      if (!sim.select(null)) throw new Error('Could not clear selection');
      sim.flushCommands();
      return selected;
    });
    await page.waitForFunction(() =>
      document.querySelector('#needs-caption').textContent === 'Select a person' &&
      document.querySelector('#activity-value').textContent === 'Nothing selected' &&
      document.querySelector('#mood-label').textContent === '' &&
      document.querySelector('#moodlet-list').childNodes.length === 0 &&
      document.querySelector('#action-queue').childNodes.length === 0);
    report = await page.evaluate(async selected => {
      const ids = ['needs-caption', 'clock-value', 'funds-value', 'satisfaction-value',
        'activity-value', 'orders-value', 'people-caption', 'people-empty', 'mood-empty', 'traits-empty'];
      const targets = ids.map(id => document.getElementById(id));
      targets.push(...document.querySelectorAll('#household-roster-members > button'));
      if (targets.length !== 13 || targets.some(target => !target || target.childNodes.length !== 1 || target.firstChild.nodeType !== 3)) {
        throw new Error('Expected 13 nonempty text targets');
      }
      const snapshots = targets.map(target => ({ target, node: target.firstChild, text: target.textContent }));
      const mutations = [];
      const observer = new MutationObserver(records => {
        for (const record of records) mutations.push({ target: record.target.id || record.target.textContent, added: record.addedNodes.length, removed: record.removedNodes.length });
      });
      for (const target of targets) observer.observe(target, { childList: true });
      const tick = globalThis.__terriStress.sim.clockTick();
      try {
        let frames = 0;
        const began = performance.now();
        await new Promise(resolve => {
          const frame = now => {
            frames += 1;
            if (now - began >= 1500) resolve();
            else requestAnimationFrame(frame);
          };
          requestAnimationFrame(frame);
        });
        const unchanged = snapshots.map(({ target, node, text }) => ({
          target: target.id || text,
          text,
          sameNode: target.firstChild === node,
          sameText: target.textContent === text,
        }));
        const pausedTick = globalThis.__terriStress.sim.clockTick();
        const pausedMutations = mutations.splice(0);
        if (pausedTick !== tick || frames < 10 || pausedMutations.length > 0 || unchanged.some(row => !row.sameNode || !row.sameText)) {
          return { pass: false, phase: 'paused', tick, pausedTick, frames, unchanged, pausedMutations };
        }
        const sim = globalThis.__terriStress.sim;
        if (selected === null || !sim.select(selected)) throw new Error('Could not restore selection');
        sim.flushCommands();
        const speed = document.querySelector('#speed-3');
        speed.checked = true;
        speed.dispatchEvent(new Event('change', { bubbles: true }));
        const deadline = performance.now() + 5000;
        await new Promise((resolve, reject) => {
          const check = () => {
            const caption = snapshots[0];
            const clock = snapshots[1];
            if (caption.target.textContent !== caption.text && clock.target.textContent !== clock.text) resolve();
            else if (performance.now() > deadline) reject(new Error('Changed HUD values did not render after resume'));
            else requestAnimationFrame(check);
          };
          requestAnimationFrame(check);
        });
        const changed = snapshots.slice(0, 2).map(({ target, node, text }) => ({
          target: target.id, before: text, after: target.textContent,
          differentNode: target.firstChild !== node,
          differentNonemptyText: target.textContent.length > 0 && target.textContent !== text,
        }));
        return { pass: changed.every(row => row.differentNode && row.differentNonemptyText),
          phase: 'complete', tick, pausedTick, frames, unchanged, pausedMutations, changed };
      } finally {
        observer.disconnect();
      }
    }, selected);
    report.scripts = await page.locator('script[src]').evaluateAll(scripts => scripts.map(script => script.src));
  } finally {
    await context.close();
    await browser.close();
  }
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
  if (!report.pass) process.exitCode = 1;
}

main().catch(error => { console.error(error); process.exitCode = 1; });
