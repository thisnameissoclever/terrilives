const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require(process.env.TERRILIVES_PLAYWRIGHT_CORE ?? path.join(process.env.APPDATA, 'npm', 'node_modules', '@playwright', 'cli', 'node_modules', 'playwright-core'));
const { closeHelpAndSetThreeTimes, normalizeMemoryHud } = require('../scripts/audio-browser-proof.cjs');

async function setSpeed(page, multiplier) {
  await page.evaluate(multiplier => {
    const input = document.querySelector('#speed-' + multiplier);
    input.checked = true;
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }, multiplier);
}

async function collect(cdp) {
  await cdp.send('HeapProfiler.collectGarbage');
  await cdp.send('HeapProfiler.collectGarbage');
  const [heap, dom] = await Promise.all([
    cdp.send('Runtime.getHeapUsage'),
    cdp.send('Memory.getDOMCounters'),
  ]);
  return { documents: dom.documents, nodes: dom.nodes, listeners: dom.jsEventListeners, jsUsedBytes: heap.usedSize };
}

async function projection(page) {
  return page.evaluate(() => {
    const text = id => document.getElementById(id)?.textContent;
    const empty = id => document.getElementById(id)?.childNodes.length === 0;
    return {
      selected: globalThis.__terriStress.sim.selectedIndex(),
      tick: globalThis.__terriStress.sim.clockTick(),
      caption: text('needs-caption'),
      activity: text('activity-value'),
      dockActivity: text('dock-activity'),
      satisfaction: text('satisfaction-value'),
      career: text('career-value'),
      orders: text('orders-value'),
      mood: text('mood-label'),
      peopleCaption: text('people-caption'),
      emptyLists: ['moodlet-list', 'action-queue', 'people-list', 'trait-list'].map(id => ({ id, empty: empty(id) })),
      warningsEmpty: [...document.querySelectorAll('#needs-content .need-state')].every(node => node.childNodes.length === 0),
    };
  });
}

function sameStructural(left, right) {
  return ['documents', 'nodes', 'listeners'].every(key => left[key] === right[key]);
}

function emptyProjection(value) {
  return value.selected === null && value.caption === 'Select a person' &&
    value.activity === 'Nothing selected' && value.dockActivity === 'Nothing selected' &&
    value.satisfaction === 'unavailable' && value.career === '' && value.orders === '0' &&
    value.mood === '' && value.peopleCaption === 'People' && value.warningsEmpty &&
    value.emptyLists.every(row => row.empty);
}

async function main() {
  if (typeof normalizeMemoryHud !== 'function') throw new Error('Corrected normalizer export is not ready');
  const browser = await chromium.launch({ channel: 'chrome', headless: false });
  let page;
  let report;
  try {
    page = await browser.newPage({ viewport: { width: 1400, height: 900 } });
    const cdp = await page.context().newCDPSession(page);
    await page.goto('http://127.0.0.1:5221/?stress=1000&audio=0', { waitUntil: 'networkidle' });
    await page.bringToFront();
    await page.waitForFunction(() => globalThis.__terriStress?.entities === 1037);
    await closeHelpAndSetThreeTimes(page);
    const initialTick = await page.evaluate(() => globalThis.__terriStress.sim.clockTick());
    await page.waitForFunction(start => globalThis.__terriStress.sim.clockTick() - start >= 60, initialTick);
    await setSpeed(page, 0);
    const selectedBefore = await page.evaluate(() => ({ selected: globalThis.__terriStress.sim.selectedIndex(), career: document.querySelector('#career-value').textContent }));
    const selected = await normalizeMemoryHud(page);
    const baselineProjection = await projection(page);
    const baseline = await collect(cdp);

    await page.evaluate(selected => {
      const sim = globalThis.__terriStress.sim;
      if (!sim.select(selected)) throw new Error('Could not restore selected person');
      sim.flushCommands();
    }, selected);
    await setSpeed(page, 3);
    await page.waitForFunction(start => globalThis.__terriStress.sim.clockTick() - start >= 60, baselineProjection.tick);
    await setSpeed(page, 0);
    await normalizeMemoryHud(page);
    const finalProjection = await projection(page);
    const final = await collect(cdp);

    await page.evaluate(() => {
      globalThis.__memoryFaultText = document.createTextNode('Detached node detection control');
    });
    const retainedNode = await collect(cdp);
    await page.evaluate(() => { delete globalThis.__memoryFaultText; });
    const afterNodeCleanup = await collect(cdp);

    await page.evaluate(() => {
      globalThis.__memoryFaultListener = () => {};
      window.addEventListener('memory-proof-fault-control', globalThis.__memoryFaultListener);
    });
    const retainedListener = await collect(cdp);
    await page.evaluate(() => {
      window.removeEventListener('memory-proof-fault-control', globalThis.__memoryFaultListener);
      delete globalThis.__memoryFaultListener;
    });
    const afterListenerCleanup = await collect(cdp);
    const checks = {
      selectedPersonExercised: selectedBefore.selected !== null && selectedBefore.career.length > 0,
      baselineComplete: emptyProjection(baselineProjection),
      finalComplete: emptyProjection(finalProjection),
      endpointsEqual: sameStructural(baseline, final),
      detachedNodeDetected: retainedNode.nodes === final.nodes + 1 && retainedNode.documents === final.documents && retainedNode.listeners === final.listeners,
      detachedNodeCleanup: sameStructural(afterNodeCleanup, final),
      listenerDetected: retainedListener.listeners === final.listeners + 1 && retainedListener.nodes === final.nodes && retainedListener.documents === final.documents,
      listenerCleanup: sameStructural(afterListenerCleanup, final),
    };
    report = { pass: Object.values(checks).every(Boolean), checks, selectedBefore,
      baselineProjection, finalProjection, baseline, final,
      retainedNode, afterNodeCleanup, retainedListener, afterListenerCleanup,
      scripts: await page.locator('script[src]').evaluateAll(nodes => nodes.map(node => node.src)),
    };
  } finally {
    if (page && !page.isClosed()) {
      await page.evaluate(() => {
        delete globalThis.__memoryFaultText;
        if (globalThis.__memoryFaultListener) {
          window.removeEventListener('memory-proof-fault-control', globalThis.__memoryFaultListener);
          delete globalThis.__memoryFaultListener;
        }
      }).catch(() => {});
    }
    await browser.close();
  }
  fs.writeFileSync('.tmp/memory-normalizer-browser.json', JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
  if (!report.pass) process.exitCode = 1;
}

main().catch(error => { console.error(error); process.exitCode = 1; });
