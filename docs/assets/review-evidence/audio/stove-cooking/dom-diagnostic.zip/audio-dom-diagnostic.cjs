const fs = require('node:fs');
const path = require('node:path');

const FIXED_TICKS = 600;
const WARMUP_TICKS = 60;
const MEMORY_STEP_TICKS = 60;
const AUDIO_RETAINED_ALLOWANCE_BYTES = 64 * 1024;

function parseArgs(argv) {
  const result = {
    mode: 'performance',
    url: 'http://127.0.0.1:4173/',
    output: null,
  };
  const readValue = (flag, index) => {
    const value = argv[index + 1];
    if (typeof value !== 'string' || value.length === 0 || value.startsWith('--')) {
      throw new Error(`missing value for ${flag}`);
    }
    return value;
  };
  for (let index = 0; index < argv.length; index += 1) {
    const value = argv[index];
    if (value === 'performance' || value === 'memory' || value === 'scheduler') {
      result.mode = value;
    } else if (value === '--url') {
      result.url = readValue(value, index++);
    } else if (value === '--output') {
      result.output = readValue(value, index++);
    } else {
      throw new Error(`unknown argument: ${value}`);
    }
  }
  return result;
}

function loadPlaywright() {
  const configured = process.env.TERRILIVES_PLAYWRIGHT_CORE;
  const globalRoot = path.join(process.env.APPDATA ?? '', 'npm', 'node_modules');
  const candidates = [
    configured,
    path.join(globalRoot, '@playwright', 'cli', 'node_modules', 'playwright-core'),
    path.join(globalRoot, 'playwright-core'),
  ].filter(Boolean);
  const found = candidates.find((candidate) =>
    fs.existsSync(path.join(candidate, 'package.json')),
  );
  if (found === undefined) {
    throw new Error(
      'Playwright Core was not found. Install the existing Codex Playwright CLI or set TERRILIVES_PLAYWRIGHT_CORE.',
    );
  }
  return require(found);
}

function withQuery(baseUrl, audioEnabled) {
  const url = new URL(baseUrl);
  url.searchParams.set('stress', '1000');
  if (!audioEnabled) url.searchParams.set('audio', '0');
  return url.toString();
}

async function waitForStress(page) {
  await page.waitForFunction(
    () => globalThis.__terriStress?.entities === 1037,
    undefined,
    { polling: 100, timeout: 60_000 },
  );
}

async function closeHelpAndSetThreeTimes(page) {
  const close = page.locator('#close-help');
  if (await close.isVisible()) await close.click();
  // Always deliver a real gesture, even when first-run Help is already closed.
  await page.locator('#options-toggle').click();
  await page.locator('#options-close').click();
  await setSpeed(page, 3);
  await page.waitForTimeout(250);
}

async function setSpeed(page, multiplier) {
  await page.evaluate((multiplier) => {
    const speed = document.querySelector(`#speed-${multiplier}`);
    if (!(speed instanceof HTMLInputElement)) {
      throw new Error(`missing #speed-${multiplier} input`);
    }
    speed.checked = true;
    speed.dispatchEvent(new Event('change', { bubbles: true }));
  }, multiplier);
}

function percentile(sorted, fraction) {
  if (sorted.length === 0) return 0;
  return sorted[Math.ceil(sorted.length * fraction) - 1];
}

function stats(values) {
  const sorted = [...values].sort((left, right) => left - right);
  return {
    count: sorted.length,
    mean: sorted.reduce((sum, value) => sum + value, 0) / sorted.length,
    p50: percentile(sorted, 0.5),
    p95: percentile(sorted, 0.95),
    max: sorted.at(-1) ?? 0,
  };
}

async function calibrateRefresh(page) {
  return page.evaluate(
    () =>
      new Promise((resolve) => {
        const intervals = [];
        let first = null;
        let previous = null;
        function frame(timestamp) {
          if (first === null) first = timestamp;
          if (previous !== null) intervals.push(timestamp - previous);
          previous = timestamp;
          if (timestamp - first >= 5_000) {
            resolve({ durationMs: timestamp - first, intervals });
            return;
          }
          requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
      }),
  );
}

async function runPerformance(browser, baseUrl, audioEnabled) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  const page = await context.newPage();
  try {
    await page.goto(withQuery(baseUrl, audioEnabled), { waitUntil: 'networkidle' });
    await page.bringToFront();
    await waitForStress(page);

    const calibrationRaw = await calibrateRefresh(page);
    const calibration = stats(calibrationRaw.intervals);
    const calibrationHz =
      (calibrationRaw.intervals.length * 1_000) / calibrationRaw.durationMs;

    await closeHelpAndSetThreeTimes(page);
    const result = await page.evaluate(
      async ({ warmupTicks, retainedTicks }) => {
        const stress = globalThis.__terriStress;
        if (stress === undefined) throw new Error('stress handle disappeared');

        const warmupStart = stress.sim.clockTick();
        await new Promise((resolve) => {
          const check = () => {
            if (stress.sim.clockTick() - warmupStart >= warmupTicks) resolve();
            else requestAnimationFrame(check);
          };
          requestAnimationFrame(check);
        });

        const work = [];
        const intervals = [];
        const timer = stress.timer;
        const originalSample = timer.sample.bind(timer);
        timer.sample = (elapsedMs) => {
          work.push(elapsedMs);
          originalSample(elapsedMs);
        };
        let simIdOfCalls = 0;
        const originalSimIdOf = stress.sim.simIdOf.bind(stress.sim);
        stress.sim.simIdOf = (...args) => {
          simIdOfCalls += 1;
          return originalSimIdOf(...args);
        };

        const startTick = stress.sim.clockTick();
        let firstTimestamp = null;
        let previousTimestamp = null;
        try {
          await new Promise((resolve) => {
            const collect = (timestamp) => {
              if (firstTimestamp === null) firstTimestamp = timestamp;
              if (previousTimestamp !== null) {
                intervals.push(timestamp - previousTimestamp);
              }
              previousTimestamp = timestamp;
              if (stress.sim.clockTick() - startTick >= retainedTicks) resolve();
              else requestAnimationFrame(collect);
            };
            requestAnimationFrame(collect);
          });
        } finally {
          timer.sample = originalSample;
          stress.sim.simIdOf = originalSimIdOf;
        }

        return {
          entities: stress.entities,
          fixedTicks: stress.sim.clockTick() - startTick,
          durationMs: previousTimestamp - firstTimestamp,
          intervals,
          work,
          simIdOfCalls,
          sampler: {
            frames: stress.footstepSampler.frames,
            window: stress.footstepSampler.windowSize,
            mean: stress.footstepSampler.mean,
            p95: stress.footstepSampler.p95,
            max: stress.footstepSampler.max,
          },
        };
      },
      { warmupTicks: WARMUP_TICKS, retainedTicks: FIXED_TICKS - WARMUP_TICKS },
    );

    const intervals = stats(result.intervals);
    const work = stats(result.work);
    return {
      audioEnabled,
      calibration: { achievedHz: calibrationHz, ...calibration },
      active: {
        entities: result.entities,
        fixedTicks: result.fixedTicks,
        achievedHz: (result.intervals.length * 1_000) / result.durationMs,
        intervals,
        framesOver16_6Ms: result.intervals.filter((value) => value > 16.6).length,
        work,
        workFramesOver16_6Ms: result.work.filter((value) => value > 16.6).length,
        simIdOfCalls: result.simIdOfCalls,
        sampler: result.sampler,
      },
    };
  } finally {
    await context.close();
  }
}

async function collectMemorySample(page, cdp, includePageMemory) {
  await cdp.send('HeapProfiler.collectGarbage');
  await page.evaluate(() => { globalThis.__domWrites.length = 0; });
  const pageMemory = await page.evaluate(async ({ enabled, timeoutMs }) => {
      if (!enabled || typeof performance.measureUserAgentSpecificMemory !== 'function') {
        return null;
      }
      return Promise.race([
        performance.measureUserAgentSpecificMemory().then((measurement) => ({
          bytes: measurement.bytes,
          timedOut: false,
        })),
        new Promise((resolve) => {
          setTimeout(() => resolve({ bytes: null, timedOut: true }), timeoutMs);
        }),
      ]);
    }, { enabled: includePageMemory, timeoutMs: 10_000 });
  // The broad page measurement can briefly create diagnostic objects of its
  // own. Collect once more before reading the retained structural counters so
  // the harness does not fail because its thermometer is still in the room.
  await cdp.send('HeapProfiler.collectGarbage');
  const [heap, dom, diagnostics] = await Promise.all([
    cdp.send('Runtime.getHeapUsage'),
    cdp.send('Memory.getDOMCounters'),
    page.evaluate(() => {
      const stress = globalThis.__terriStress;
      if (stress === undefined) throw new Error('stress handle disappeared');
      return {
        tick: stress.sim.clockTick(),
        entities: stress.entities,
        wasmMemoryBytes: stress.wasmMemoryBytes,
        activeVoices: stress.audio.activeVoices,
        footstepTracks: stress.audio.footstepTracks,
        footstepCapacity: stress.audio.footstepCapacity,
        activityTracks: stress.audio.activityTracks,
        activityCapacity: stress.audio.activityCapacity,
        objectSoundTracks: stress.audio.objectSoundTracks,
        objectSoundCapacity: stress.audio.objectSoundCapacity,
        conversationVoices: stress.audio.conversationVoices,
        retainedConversationVoices: stress.audio.retainedConversationVoices,
        objectLoopVoices: stress.audio.objectLoopVoices,
        retainedObjectLoopVoices: stress.audio.retainedObjectLoopVoices,
        doorVoices: stress.audio.doorVoices,
        doorTracks: stress.audio.doorTracks,
        doorCapacity: stress.audio.doorCapacity,
      };
    }),
  ]);
  return {
    ...diagnostics,
    jsUsedBytes: heap.usedSize,
    jsEmbedderBytes: heap.embedderHeapUsedSize,
    backingStorageBytes: heap.backingStorageSize,
    pageMemoryBytes: pageMemory?.bytes ?? null,
    pageMemoryTimedOut: pageMemory?.timedOut ?? false,
    domDocuments: dom.documents,
    domNodes: dom.nodes,
    eventListeners: dom.jsEventListeners,
    writes: await page.evaluate(() => globalThis.__domWrites.splice(0)),
  };
}

async function runMemory(browser, baseUrl, audioEnabled, repetition) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  const page = await context.newPage();
  const cdp = await context.newCDPSession(page);
  try {
    await page.goto(withQuery(baseUrl, audioEnabled), { waitUntil: 'networkidle' });
    await page.bringToFront();
    await waitForStress(page);
    await closeHelpAndSetThreeTimes(page);

    await page.evaluate(() => {
      globalThis.__domWrites = [];
      const descriptor = Object.getOwnPropertyDescriptor(Node.prototype, 'textContent');
      Object.defineProperty(Node.prototype, 'textContent', {
        ...descriptor,
        set(value) {
          const before = descriptor.get.call(this);
          const id = this.id || this.nodeName;
          const children = this.childNodes.length;
          if (globalThis.__skipSameText && before === value &&
              !(globalThis.__allowCaption && id === 'needs-caption')) return;
          descriptor.set.call(this, value);
          globalThis.__domWrites.push({ id, before, value, children, now: performance.now() });
        },
      });
    });

    const startTick = await page.evaluate(() => globalThis.__terriStress.sim.clockTick());
    await page.waitForFunction(
      (start) => globalThis.__terriStress.sim.clockTick() - start >= 60,
      startTick,
      { polling: 100, timeout: 30_000 },
    );

    const samples = [];
    await setSpeed(page, 0);
    const selected = await normalizeMemoryHud(page);
    await waitForAudioDrain(page);
    samples.push(await collectMemorySample(page, cdp, true));
    const baselineDom = await captureDom(page);
    const baselineProbes = [];
    for (let probe = 0; probe < 750; probe += 1) {
      if (probe === 250) await page.evaluate(() => { globalThis.__skipSameText = true; });
      if (probe === 500) await page.evaluate(() => { globalThis.__allowCaption = true; });
      const sample = await collectMemorySample(page, cdp, false);
      const dom = sample.domNodes !== 1434 ? await captureDom(page) : [];
      baselineProbes.push({ sample, dom, phase: probe < 250 ? 'original' : probe < 500 ? 'skip-unchanged' : 'caption-only' });
      if (sample.domNodes !== samples[0].domNodes) {
        console.error('DOM counter changed', probe, sample.domNodes);
      }
    }
    return { repetition, audioEnabled, samples, baselineDom, baselineProbes };
    const baselineTick = samples[0].tick;
    await page.evaluate(entity => {
      const sim = globalThis.__terriStress.sim;
      if (!sim.select(entity)) throw new Error('Could not restore memory-run selection');
      sim.flushCommands();
    }, selected);
    await setSpeed(page, 3);
    await page.waitForTimeout(250);
    for (
      let target = MEMORY_STEP_TICKS;
      target < FIXED_TICKS - WARMUP_TICKS;
      target += MEMORY_STEP_TICKS
    ) {
      await page.waitForFunction(
        ({ baseline, delta }) => globalThis.__terriStress.sim.clockTick() - baseline >= delta,
        { baseline: baselineTick, delta: target },
        { polling: 100, timeout: 30_000 },
      );
      samples.push(await collectMemorySample(page, cdp, false));
    }
    await page.waitForFunction(
      ({ baseline, delta }) => globalThis.__terriStress.sim.clockTick() - baseline >= delta,
      { baseline: baselineTick, delta: FIXED_TICKS - WARMUP_TICKS },
      { polling: 100, timeout: 30_000 },
    );
    await setSpeed(page, 0);
    await normalizeMemoryHud(page);
    await waitForAudioDrain(page);
    samples.push(await collectMemorySample(page, cdp, true));
    const finalDom = await captureDom(page);

    return { repetition, audioEnabled, samples, baselineDom, finalDom };
  } finally {
    await context.close();
  }
}

async function captureDom(page) {
  return page.evaluate(() => {
    const result = [];
    function visit(node, path) {
      const label = node.nodeName + (node.id ? '#' + node.id : '');
      const key = path + '/' + label;
      result.push({ path: key, type: node.nodeType, value: node.nodeType === 3 ? node.nodeValue : null });
      Array.from(node.childNodes).forEach((child, index) => visit(child, key + '[' + index + ']'));
      if (node.shadowRoot) visit(node.shadowRoot, key + '/shadow');
    }
    visit(document, '');
    return result;
  });
}

async function normalizeMemoryHud(page) {
  const selected = await page.evaluate(() => {
    const sim = globalThis.__terriStress.sim;
    const previous = sim.selectedIndex();
    if (!sim.select(null)) throw new Error('Could not clear memory-run selection');
    sim.flushCommands();
    return previous;
  });
  // Compare identical empty selected-person panels, while the measured
  // interval still renders normal changing moodlets and action cards.
  await page.waitForFunction(() => {
    const warnings = document.querySelectorAll('#needs-content .need-state');
    return globalThis.__terriStress.sim.selectedIndex() === null &&
      document.querySelector('#moodlet-list')?.childNodes.length === 0 &&
      document.querySelector('#action-queue')?.childNodes.length === 0 &&
      warnings.length === 7 && Array.from(warnings).every(span => span.childNodes.length === 0);
  }, undefined, { polling: 50, timeout: 5000 });
  return selected;
}

async function waitForAudioDrain(page) {
  // Pause allows short cues and conversations to finish. Their onended
  // listeners are live ownership, not leaked listeners.
  await page.waitForFunction(() => {
    const audio = globalThis.__terriStress.audio;
    return audio.activeVoices === 0 && audio.doorVoices === 0 &&
      audio.conversationVoices === 0 && audio.retainedConversationVoices === 0 &&
      audio.objectLoopVoices === 0 && audio.retainedObjectLoopVoices === 0;
  }, undefined, { polling: 50, timeout: 10_000 });
}

function growth(run, field) {
  const first = run.samples[0][field];
  const last = run.samples.at(-1)[field];
  return first === null || last === null ? null : last - first;
}

function median(values) {
  const sorted = [...values].sort((left, right) => left - right);
  return sorted[Math.floor(sorted.length / 2)];
}

function analyseMemory(runs) {
  const pairs = [0, 1, 2].map((repetition) => {
    const enabled = runs.find((run) => run.repetition === repetition && run.audioEnabled);
    const disabled = runs.find((run) => run.repetition === repetition && !run.audioEnabled);
    const enabledJs = growth(enabled, 'jsUsedBytes');
    const disabledJs = growth(disabled, 'jsUsedBytes');
    return {
      repetition,
      enabledJsGrowthBytes: enabledJs,
      disabledJsGrowthBytes: disabledJs,
      audioSpecificJsGrowthBytes: enabledJs - disabledJs,
      enabledPageGrowthBytes: growth(enabled, 'pageMemoryBytes'),
      disabledPageGrowthBytes: growth(disabled, 'pageMemoryBytes'),
      enabledWasmGrowthBytes: growth(enabled, 'wasmMemoryBytes'),
      disabledWasmGrowthBytes: growth(disabled, 'wasmMemoryBytes'),
    };
  });
  const medianAudioSpecificJsGrowthBytes = median(
    pairs.map((pair) => pair.audioSpecificJsGrowthBytes),
  );
  const structuralPass = runs.every((run) => {
    const baseline = run.samples[0];
    const final = run.samples.at(-1);
    const boundedLiveState = run.samples.every(
      (sample) =>
        sample.entities === 1037 &&
        sample.wasmMemoryBytes >= 65_536 &&
        sample.footstepCapacity === baseline.footstepCapacity &&
        sample.footstepTracks <= 3 &&
        sample.activityCapacity === baseline.activityCapacity &&
        sample.activityTracks <= 3 &&
        sample.objectSoundCapacity === baseline.objectSoundCapacity &&
        // Three household Sims can each use one of the shower, stove or sinks.
        sample.objectSoundTracks <= 3 &&
        sample.doorCapacity === baseline.doorCapacity &&
        sample.doorTracks <= 4 &&
        sample.doorVoices <= 4 &&
        sample.activeVoices <= 8 &&
        // The recorded conversation voices are a retained scheduler like the
        // rest, and `activeVoices` cannot see them: that counts oscillators
        // and these are buffer sources. Leaving them out is the exact
        // omission [L-audio-boundaries-and-proofs-must-cover-every-scheduler]
        // records, so they are bounded here in the same change that added
        // them.
        //
        // The RETAINED count is the one worth bounding. A conversation that
        // has been stopped leaves the sounding list immediately and keeps its
        // nodes until its fade has rendered, so a reclaim that stopped
        // working would be invisible to the sounding count alone.
        // Six, not three: the retained count is the sounding ones plus the
        // ones still fading, and each is capped at three. Bounding it at the
        // number today's calling pattern happens to produce would make this
        // gate fail the day more than one conversation may sound at once,
        // which is the flake this check already had to have removed once.
        sample.conversationVoices <= 3 &&
        sample.retainedConversationVoices <= 6 &&
        sample.objectLoopVoices <= 4 &&
        sample.retainedObjectLoopVoices <= 8,
    );
    return (
      boundedLiveState &&
      (!run.audioEnabled || run.samples.some(sample => sample.doorTracks > 0)) &&
      // Intermediate samples may be sounding. Endpoints wait for natural
      // completion so listener comparisons measure retained ownership.
      [baseline, final].every(sample => ['activeVoices', 'objectLoopVoices',
        'doorVoices', 'conversationVoices', 'retainedConversationVoices',
        'retainedObjectLoopVoices'].every(field => sample[field] === 0)) &&
      final.domDocuments === baseline.domDocuments &&
      final.domNodes === baseline.domNodes &&
      final.eventListeners === baseline.eventListeners
    );
  });
  return {
    allowanceBytes: AUDIO_RETAINED_ALLOWANCE_BYTES,
    pairs,
    medianAudioSpecificJsGrowthBytes,
    retainedAudioPass:
      medianAudioSpecificJsGrowthBytes <= AUDIO_RETAINED_ALLOWANCE_BYTES,
    structuralPass,
  };
}

async function runScheduler(browser, baseUrl) {
  const context = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  const page = await context.newPage();
  try {
    await page.goto(withQuery(baseUrl, true), { waitUntil: 'networkidle' });
    await waitForStress(page);
    return page.evaluate(() => globalThis.__terriStress.runFootstepSchedulerProbe(40, 600));
  } finally {
    await context.close();
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const { chromium } = loadPlaywright();
  const browser = await chromium.launch({
    channel: 'chrome',
    headless: false,
    args: [
      '--window-position=0,0',
      '--window-size=1400,900',
      '--enable-blink-features=ForceEagerMeasureMemory',
    ],
  });
  let report;
  try {
    if (args.mode === 'performance') {
      const enabled = await runPerformance(browser, args.url, true);
      const disabled = await runPerformance(browser, args.url, false);
      report = {
        mode: args.mode,
        generatedAt: new Date().toISOString(),
        enabled,
        disabled,
        p95RegressionMs: enabled.active.work.p95 - disabled.active.work.p95,
        pass:
          enabled.calibration.achievedHz >= 118 &&
          enabled.calibration.achievedHz <= 122 &&
          disabled.calibration.achievedHz >= 118 &&
          disabled.calibration.achievedHz <= 122 &&
          enabled.active.sampler.p95 <= 0.25 &&
          enabled.active.sampler.max <= 1 &&
          enabled.active.work.p95 - disabled.active.work.p95 <= 1 &&
          enabled.active.workFramesOver16_6Ms === 0 &&
          disabled.active.workFramesOver16_6Ms === 0 &&
          enabled.active.simIdOfCalls === 0 &&
          disabled.active.simIdOfCalls === 0,
      };
    } else if (args.mode === 'memory') {
      const runs = [];
      for (let repetition = 0; repetition < 1; repetition += 1) {
        const order = [false];
        for (const audioEnabled of order) {
          runs.push(await runMemory(browser, args.url, audioEnabled, repetition));
        }
      }
      report = {
        mode: args.mode,
        generatedAt: new Date().toISOString(),
        contract: {
          repetitions: 3,
          warmupTicks: WARMUP_TICKS,
          measuredTicks: FIXED_TICKS - WARMUP_TICKS,
          sampleEveryTicks: MEMORY_STEP_TICKS,
          audioRetainedAllowanceBytes: AUDIO_RETAINED_ALLOWANCE_BYTES,
        },
        runs,
        analysis: { retainedAudioPass: false, structuralPass: false },
      };
    } else {
      const result = await runScheduler(browser, args.url);
      report = {
        mode: args.mode,
        generatedAt: new Date().toISOString(),
        result,
        pass:
          result.walkers === 40 &&
          result.ticks === 600 &&
          result.tracks === 40 &&
          result.capacity >= 40 &&
          result.p95MsPerTick <= 0.25 &&
          result.maxMsPerTick <= 1,
      };
    }
  } finally {
    await browser.close();
  }

  const json = `${JSON.stringify(report, null, 2)}\n`;
  if (args.output !== null) fs.writeFileSync(args.output, json, 'utf8');
  process.stdout.write(JSON.stringify({ output: args.output, diagnostic: true }));
  const pass =
    report.mode === 'memory'
      ? report.analysis.retainedAudioPass && report.analysis.structuralPass
      : report.pass;
  if (!pass) process.exitCode = 1;
}

module.exports = { analyseMemory, closeHelpAndSetThreeTimes };

if (require.main === module) main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
